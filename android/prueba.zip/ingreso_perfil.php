
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="estilo.css">
    <title></title>
  </head>
  <body>
    <?php $id=$_GET['id']; ?>
    <div class="">
      <form class="fromulario" action="guardar_perfil.php?id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
        <div class="divs">
        <label for="" class="etiq">Nombres</label>
        <input type="text" class="cajas" name="nombre" disabled value="Bryan Elias Veliz peña">
        <label for="" class="etiq">Cargo</label>
        <input type="text" class="cajas"  name="cargo" disabled value="Administrador">
        <label for="" class="etiq">Area</label>
        <input type="text" class="cajas"  name="area" disabled value="Logistica">
        </div>
        <div class="divs2">
          <img src="logo_foto.jpg" alt="" width="170" height="180">
          <input type="file" class="cajas" name="image" >
        </div>
        <div class="divs3">
          <label for="" class="etiq2">Ubicaión</label>
          <input type="text" class="cajas2"  name="ubi" value="" placeholder="Ubicaión">
          <label for="" class="etiq2">Email</label>
          <input type="text" class="cajas2"  name="correo" value="" placeholder="correo">
          <label for="" class="etiq2">Telefono</label>
          <input type="text" class="cajas2"  name="tele" value="" placeholder="Telefono">
          <label for="" class="etiq2">Fecha de nacimiento</label>
          <input type="date" class="cajas2"  name="Fnaci">
        </div>
        <div class="div3">
          <input type="submit" class="bto" name="" value="ACTUALIZAR">
        </div>
      </form>

    </div>
    <?php echo $id; ?>
  </body>
</html>
