/* ============================== */
$(window).on("load", function(){
    $('#xin_tasks').perfectScrollbar({
        wheelPropagation: true
    });
	 $('#xin_projects').perfectScrollbar({
        wheelPropagation: true
    });
});	